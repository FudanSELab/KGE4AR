class Constant:
    METHOD = "method"
    LIBRARY = "library"
    CLASS = "class"
    PACKAGE = "package"
